<?php $__env->startSection('title'); ?>
<?php echo e($user->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-md-3">
          <div class="card overflow-hidden">
            <div class="card-header text-white bg-custom text-center">Profile Picture</div>
            <div class="card nb">
            <img class="card-img-top img-thumbnail" src="<?php echo e(asset(Str::startsWith($user->avatar,'img/') ? $user->avatar : 'storage/'.$user->avatar)); ?>" alt="">
            <div class="card-body">
              <?php if(auth()->user()->id == $user->id): ?>
              <form action="<?php echo e(route('image-save')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                  <input class="form-control" type="file" name="image" id="">
                </div>
                <input class="btn btn-sm bg-custom nb text-white form-control" type="submit" value="Save">
              </form>
              <?php else: ?>
              <div class="form-group">
                <button class="btn form-control nb bg-custom text-white">Hello, there !</button>
              </div>
              <friend-btn :user_id="<?php echo e($user->id); ?>"></friend-btn>
              <?php endif; ?>
            </div>
            </div>
          </div>
        </div>
        <div class="col-md-8">
          <div class="card">
          <div class="card-header bg-custom text-white h5"><?php echo e($user->name); ?></div>
          <div class="card-body">
           

            <blockquote class="blockquote mb-5">
              <p class="h6 mb-0"><?php echo e($user->profile? $user->profile->about: 'N/A'); ?></p>
            <footer class="blockquote-footer text-right">About me</footer>
            </blockquote>
            <table class="table table-hover">
              <tbody>
                <tr>
                  <th><i class="fas fa-user-tie"></i> Name</th>
                  <th><?php echo e($user->name); ?></th>
                </tr>
                <tr>
                  <td class="text-nowrap"><i class="fas fa-envelope-open"></i></i> Primary email</td>
                <td><a href="mailto:<?php echo e($user->email); ?>"><?php echo e($user->email); ?></a> </td>
                </tr>
                <tr>
                  <td class="text-nowrap"><i class="fas fa-envelope"></i> Secondary email</td>
                  <td><a href="mailto:<?php echo e($user->secondary_email); ?>"><?php echo e($user->secondary_email ?: 'N/A'); ?></a></td>
                </tr>
                <tr>
                  <td class="text-nowrap"><i class="fas fa-graduation-cap"></i> University</td>
                  <td><?php echo e($user->university ? $user->university->name : 'N/A'); ?></td>
                </tr>
                <tr>
                  <td class="text-nowrap"><i class="fas fa-phone-square-alt"></i> Phone</td>
                  <td><?php echo e($user->profile? $user->profile->phone : 'N/A'); ?></td>
                </tr>
                <tr>
                  <td><i class="fab fa-facebook-square"> Facebook </td>
                <td><u> <a href="<?php echo e($user->social->fb); ?>" target="_blank"><?php echo e($user->social->fb ?: 'N/A'); ?></u></a></td>
                </tr>
                <tr>
                  <td><i class="fab fa-github-square"> Github </td>
                  <td><u><a href="<?php echo e($user->social->git); ?>" target="_blank"><?php echo e($user->social->git ?: 'N/A'); ?></u></a></td>
                </tr>
                <tr>
                  <td><i class="fab fa-linkedin"> LinkedIn </i></td>
                  <td><u><a href="<?php echo e($user->social->l_i); ?>" target="_blank"><?php echo e($user->social->l_i ?: 'N/A'); ?></u></a></td>
                </tr>
                

                <tr>
                  <td><i class="fas fa-cogs"></i>  Skills</td>
                  <td>
                    <?php $__currentLoopData = $user->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="chp mb-1 <?php echo e(auth()->user()->hasSkill($item->id) ? 'cmn' : ''); ?> "> <?php echo e($item->name); ?> </span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <small class="form-text cmntxt">This is the color of common skills</small>
                  </td>
                </tr>

              </tbody>
            </table>
          </div>
          </div>

        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\laragon\www\devers\resources\views/profile/single.blade.php ENDPATH**/ ?>