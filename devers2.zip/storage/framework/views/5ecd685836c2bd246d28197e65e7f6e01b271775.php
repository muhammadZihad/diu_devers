<?php $__env->startSection('title'); ?>
News feed
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            
            <div class="col-md-3">
                <div class="img-box img-thumbnail nr">
                <img src="<?php echo e(asset('storage/avatar/cgqOYLnjNQwHlPFSZvGyDHSUwlVKwovQNbRJJyzx.jpeg')); ?>" alt="" class="avatar">
                </div>
                <ul class="list-group">
                    <li class="list-group-item nb"><b><a href="#" class="text-custom">Profile</a></b></li>
                    <li class="list-group-item nb"><b><a href="#" class="text-custom">Friends</a></b></li>
                    <li class="list-group-item nb"><b><a href="#" class="text-custom">Friend Requests</a></b></li>
                    <li class="list-group-item nb"><b><a href="#" class="text-custom">Search People</a></b></li>
                </ul>
            </div>
            
            <div class="col-md-6">
                <div class="row mb-3">
                    <div class="col-md-12">
                        <div class="d-flex justify-content-between align-items-center b1 p-2">
                            <div class="text-secondary">Working on a new <strong>project</strong> ?</div>
                            <button class="btn nr bg-custom text-white"><strong>Post here</strong></button>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 text-center">
                        See friends posts
                        <hr>
                    </div>
                </div>
                <post></post>
            </div>
            
            <div class="col-md-3">
                <h5 class="text-custom">Friend Requests</h5>
                <hr>
                <friend-req :myid="<?php echo e(auth()->user()->id); ?>"></friend-req>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\laragon\www\devers\resources\views/homepage.blade.php ENDPATH**/ ?>