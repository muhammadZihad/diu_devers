<template>
  <div class="row b1 post mb-2 p-2">
    <div class="col-12 flex-column">
      <div class="d-flex">
        <div class="img img-responsive rounded-circle d-img mr-2"></div>
        <div class="d-flex align-items-center">
          <div class="d-flex flex-column">
            <h5 class="h5 text-custom m-0">Muhammad Zihad</h5>
            <p class="small m-0">12:30 26 March 2020</p>
          </div>
        </div>
      </div>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus iusto mollitia neque a ratione quia, culpa consequuntur, quibusdam, asperiores officiis eligendi quod tempora soluta sed dicta sunt aspernatur vitae. Aliquam.</p>
      <div class="row justify-content-center">
        <div class="col-8">
          <div class="post-img"></div>
        </div>
      </div>
      <div class="row p-2">
        <div class="col-12 d-flex b1 p-2">
          <div class="d-flex align-items-center">
            <div class="link-img-box"></div>
          </div>
          <div class="link-details ml-2">
            <h4 class="h5 text-custm">
              <a href="#">github/muhammadZihad</a>
            </h4>
            <p
              class="m-0 text-muted"
            >Lorem, ipsum dolor sit amet consectetur adipisicing elit. Non fuga quos optio corrupti voluptas itaque aut quisquam sit mollitia asperiores.</p>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-4 p-2">
          <button class="btn-sm nr b-like">Like</button>
          <button class="btn-sm nr b-clap bg">Claped</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>