@extends('layouts.app')

@section('title')
News feed
@endsection

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            {{-- This is left sidebar --}}
            <div class="col-md-3">
                <div class="img-box img-thumbnail nr">
                <img src="{{asset('storage/avatar/cgqOYLnjNQwHlPFSZvGyDHSUwlVKwovQNbRJJyzx.jpeg')}}" alt="" class="avatar">
                </div>
                <ul class="list-group">
                    <li class="list-group-item nb"><b><a href="#" class="text-custom">Profile</a></b></li>
                    <li class="list-group-item nb"><b><a href="#" class="text-custom">Friends</a></b></li>
                    <li class="list-group-item nb"><b><a href="#" class="text-custom">Friend Requests</a></b></li>
                    <li class="list-group-item nb"><b><a href="#" class="text-custom">Search People</a></b></li>
                </ul>
            </div>
            {{-- This is newsfeed --}}
            <div class="col-md-6">
                <div class="row mb-3">
                    <div class="col-md-12">
                        <div class="d-flex justify-content-between align-items-center b1 p-2">
                            <div class="text-secondary">Working on a new <strong>project</strong> ?</div>
                            <button class="btn nr bg-custom text-white"><strong>Post here</strong></button>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 text-center">
                        See friends posts
                        <hr>
                    </div>
                </div>
                <post></post>
            </div>
            {{-- This is right sidebar --}}
            <div class="col-md-3">
                <h5 class="text-custom">Friend Requests</h5>
                <hr>
                <friend-req :myid="{{auth()->user()->id}}"></friend-req>
            </div>
        </div>
    </div>
@endsection